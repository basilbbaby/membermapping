package com.ust.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.member.dao.MemberDao;
import com.ust.member.model.Member;

@Service
public class MemberServiceImpl implements MemberService{
	
	@Autowired
	MemberDao memDao;

	@Override
	public List<Member> displayMember() {
		return memDao.diplayMember();
	}

	@Override
	public Member addMember(Member member) {
		return memDao.addMember(member);
	}
	
	


}
