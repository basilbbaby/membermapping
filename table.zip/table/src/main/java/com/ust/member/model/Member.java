package com.ust.member.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name = "mbr")
@JsonIgnoreProperties({"mbr_id"})

public class Member {

	@Id	

	@GeneratedValue(strategy=GenerationType.AUTO)
	int mbr_id;
	String f_name;
	String l_name;
	String dob;
	String gnr_cd;
	String mc_id;
	@OneToMany(fetch = FetchType.EAGER,cascade=CascadeType.ALL)
//	@JoinColumn(name = "mem_cntrct_id")
	@Column(name="mbr_ct")
	Set<Member_Contract> member_contracts;
	public Member() {
		super();
	}
	public Member(int mbr_id, String f_name, String l_name, String dob, String gnr_cd, String mc_id,
			Set<Member_Contract> member_contracts) {
		super();
		this.mbr_id = mbr_id;
		this.f_name = f_name;
		this.l_name = l_name;
		this.dob = dob;
		this.gnr_cd = gnr_cd;
		this.mc_id = mc_id;
		this.member_contracts = member_contracts;
	}
	public int getMbr_id() {
		return mbr_id;
	}
	public void setMbr_id(int mbr_id) {
		this.mbr_id = mbr_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGnr_cd() {
		return gnr_cd;
	}
	public void setGnr_cd(String gnr_cd) {
		this.gnr_cd = gnr_cd;
	}
	public String getMc_id() {
		return mc_id;
	}
	public void setMc_id(String mc_id) {
		this.mc_id = mc_id;
	}
	public Set<Member_Contract> getMember_contracts() {
		return member_contracts;
	}
	public void setMember_contracts(Set<Member_Contract> member_contracts) {
		this.member_contracts = member_contracts;
	}
	
	

	

}
