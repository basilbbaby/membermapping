package com.ust.member.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name="mbr_ct")
@JsonIgnoreProperties({"mem_cntrct_id"})
public class Member_Contract {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, 
      generator = "SEQUENCEE")
	@SequenceGenerator(name = "SEQUENCEE", sequenceName = "SEQUENCEE", allocationSize = 1)
	@Column(name="mbr_ct_id")
	int mem_cntrct_id;
	int scr_cd;
	int hc_id;
	String grp_id;
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name = "mbr_id")
	Member mbr;
	
	@OneToMany(fetch = FetchType.EAGER,cascade=CascadeType.ALL)
 	@Column(name="mbr_cvr")
	Set<Member_coverage> member_coverages;

	public Member_Contract() {
		super();
	}

	public Member_Contract(int mem_cntrct_id, int scr_cd, int hc_id, String grp_id,
			Set<Member_coverage> member_coverages) {
		super();
		this.mem_cntrct_id = mem_cntrct_id;
		this.scr_cd = scr_cd;
		this.hc_id = hc_id;
		this.grp_id = grp_id;
		this.member_coverages = member_coverages;
	}

	public int getMem_cntrct_id() {
		return mem_cntrct_id;
	}

	public void setMem_cntrct_id(int mem_cntrct_id) {
		this.mem_cntrct_id = mem_cntrct_id;
	}

	public int getScr_cd() {
		return scr_cd;
	}

	public void setScr_cd(int scr_cd) {
		this.scr_cd = scr_cd;
	}

	public int getHc_id() {
		return hc_id;
	}

	public void setHc_id(int hc_id) {
		this.hc_id = hc_id;
	}

	public String getGrp_id() {
		return grp_id;
	}

	public void setGrp_id(String grp_id) {
		this.grp_id = grp_id;
	}

	public Set<Member_coverage> getMember_coverages() {
		return member_coverages;
	}

	public void setMember_coverages(Set<Member_coverage> member_coverages) {
		this.member_coverages = member_coverages;
	}

	

	
	
	
	
	
	
	
	
	
}

