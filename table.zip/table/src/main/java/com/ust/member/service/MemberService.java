package com.ust.member.service;

import java.util.List;

import com.ust.member.model.Member;

public interface MemberService {
	
	public List<Member> displayMember();

	public Member addMember(Member member);


}
