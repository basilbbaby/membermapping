package com.ust.member.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ust.member.model.Member;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	SessionFactory SessionFactory;

	public SessionFactory getSessionFactory() {
		return SessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		SessionFactory = sessionFactory;
	}

	@Override
	public List<Member> diplayMember() {

		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Member");
		List<Member> members = query.list();
		return members;
	}

	@Override
	public Member addMember(Member member) {
		
		//++++++++++++++++++++++++++++++++++++++++++++
		

		
			try {
				// ------------To check the YYYY count--------------
				String date1 = member.getDob();
				String[] dateCheker = date1.split("-");
				String year = dateCheker[0];
				// --------------------------
				if (year.length() == 4) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					format.setLenient(false);
					Date date2 = format.parse(date1);
					Date date = new Date();
					// -------To check the current date------
					if (!(date2.after(date))) {
						Session session = SessionFactory.openSession();
						session.beginTransaction();
						// This session also check the id alredy exist and throw exception
						try {
							session.save(member);
							session.getTransaction().commit();
							return member;
						} catch (Exception e) {
							member.setError("format error");
							return member;
						}

					} else {
						member.setError("Date format error, the date is after the current date");
						return member;
					}
				} else {
					member.setError("Date format error, requried format is (yyyy-MM-dd)");
					return member;
				}

			} catch (ParseException e2) {
				member.setError(" Date format error, requried format is (yyyy-MM-dd)");
				return member;
			}
		
		
		//+++++++++++++++++++++++++++++++++++++++++++++
		
		
		
		
		
		
		
//		
//		Session session = SessionFactory.openSession();
//		session.beginTransaction();
//		session.saveOrUpdate(member);
//		System.out.println(member.getF_name());
//		session.getTransaction().commit();
//		return member;
	}

}
